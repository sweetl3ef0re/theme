<?php
	return array(
	/* *********************** */
	/*  General Site Settings  */
	/* *********************** */
		// Meta Tags
		'meta_description'		=>	'Ragnarok Online Free to Play',
		'meta_author'			=>	'RO Server Owner',

		// Links
		'forum'					=>	'https://site.com/forums',
		'wiki'					=>	'https://mywikilink.com',

		// Options
		'cookie_warning'		=>	true,

		// Chargen
		// - We host a version of chargen that you can use in your theme.
		// - For example, this would display a mob on the mob index if you put the code into an img tag:
		//		echo $VSC['chargen_url'].'monster/'. $mvp->monster_id;
		// - vHost updates this resource each month with new item & mob sprites but you are
		// - free to use your own if you wish to display your customs.
		'chargen_url'			=> 'https://vhost.rocks/chargen/',

		// Item & Mob Image Repo
		'image_repo_url'		=>	'https://static.industrial-illusions.net/ro/',

		// Facebook
		'facebook'				=> array(
				'enable'			=> true, // Setting to false hides the sidebar box
				'app_id'			=> '363949097598870', // Create an app at https://developers.facebook.com/apps/ to use the facebook widget in the sidebar
				'uri'				=> 'vhostofficial', // Taken from the end of the url i.e. https://fb.com/vhostofficial
				'display_timeline'	=>	true,
		),

		// Global Annoucnement
		'announcement'			=> array(
			'enable'				=>	true,
			'text'					=>	'Our new website theme has been installed!',
			'colour'				=>	'info', // Bootstrap colours, danger = red, warning = yellow, info = blue, success = green
			'icon'					=>	'fa-thumbs-up', // # to disable
		),


	/* *********************** */
	/*  Footer                 */
	/* *********************** */
		// Social
		// - If you do not wish for any of these to be displayed in your footer, replace the URL with #
		'facebook-link'				=>	'https://facebook.com',
		'twitter-link'				=>	'https://twitter.com',
		'discord-link'				=>	'https://discord/server/link',
		'youtube-link'				=>	'youtubelink',
		'rms-link'					=>	'#',
		'instagram-link'			=>	'#',
		'twitch-link'				=>	'https://www.twitch.tv/',


	/* *********************** */
	/*  Home Page              */
	/* *********************** */
		// News Feed
		'news_items_per_row'		=>	'2',

		// Youtube Video
		// - User the video code after ?v= in the URL
		'youtube_video'				=>	'HfnsDshM8Yk',

		// Screenshots
		// - Add as many screenshots to the array as you like.
		// - Screenshots are in /themes/<this_theme_name>/img/screenshots/
		'screenshots'				=> array('screenEmperium000.jpg', 'screenEmperium001.jpg', 'screenEmperium002.jpg'),


	/* *********************** */
	/*  Sidebars               */
	/* *********************** */
		// Homepage Slider
		// - Place images in /themes/<this_theme_name>/img/sidebar_slider/
		'slider_enable'				=> true,
		'slider_data'				=> array(
				'1'					=> array(
					'title'				=>	'Only For This Weekend!',
					'img'				=>	'double_exp_weekend.jpg',
					'link'				=>	'https://##',
				),

				'2'					=> array(
					'title'				=>	'Happy Halloween Everyone!',
					'img'				=>	'happy_halloween.jpg',
					'link'				=>	'https://##',
				),
		),

		// World Boss Sidebar Box
		// - If you have installed the World Boss code you can enable this box to display
		// - the remaining number of kills required directly on the site.
		// - https://rathena.org/board/files/file/4097-world-boss-event/
		'worldboss'				=>	true,
		'worldboss_required_kills'=>	10000,

		// Events Sidebar
		'events'				=>	array(
			'Race to 99',
			'Screenshot Contest'
		),



	);

