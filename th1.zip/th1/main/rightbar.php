

<?php $serverNames = $this->getServerNames(); ?>
<div class="row">
	<div class="col">
		<div class="card">
			<div class="card-header"><?php if ($session->isLoggedIn()): ?>Logged in: <?php echo htmlspecialchars($session->account->userid) ?><?php else: ?>Login<?php endif ?></div>
			<div class="card-body">
				<?php if ($session->isLoggedIn()): ?>

					You are currently logged in as <strong><a href="<?php echo $this->url('account', 'view') ?>" title="View account"><?php echo htmlspecialchars($session->account->userid) ?></a></strong>.<br />
					Donation Credits: <?php echo number_format((int)$session->account->balance) ?><br />

					<?php if (count($athenaServerNames=$session->getAthenaServerNames()) > 1): ?>
						Your preferred server is:

					<select name="preferred_server" onchange="updatePreferredServer(this)"<?php if (count($athenaServerNames=$session->getAthenaServerNames()) === 1) echo ' disabled="disabled"'  ?>>
						<?php foreach ($athenaServerNames as $serverName): ?>
						<option value="<?php echo htmlspecialchars($serverName) ?>"<?php if ($server->serverName == $serverName) echo ' selected="selected"' ?>><?php echo htmlspecialchars($serverName) ?></option>
						<?php endforeach ?>
					</select>.
					<?php endif ?>
					<form action="<?php echo $this->urlWithQs ?>" method="post" name="preferred_server_form" style="display: none">
						<input type="hidden" name="preferred_server" value="" />
					</form>
					</span>

				<?php else: ?>
					<form action="<?php echo $this->url('account', 'login', array('return_url' => $params->get('return_url'))) ?>" method="post">
						<?php if (count($serverNames) === 1): ?>
						<input type="hidden" name="server" value="<?php echo htmlspecialchars($session->loginAthenaGroup->serverName) ?>">
						<?php endif ?>
						<div class="form-group">
							<label for="login_username"><?php echo htmlspecialchars(Flux::message('AccountUsernameLabel')) ?></label>
							<input type="text" name="username" class="form-control" id="login_username" value="<?php echo htmlspecialchars($params->get('username')) ?>" />
						</div>

						<div class="form-group">
							<label for="login_password"><?php echo htmlspecialchars(Flux::message('AccountPasswordLabel')) ?></label>
							<input type="password" name="password" class="form-control" id="login_password" />
						</div>


						<?php if (count($serverNames) > 1): ?>
						<div class="form-group">
							<label for="login_server"><?php echo htmlspecialchars(Flux::message('AccountServerLabel')) ?></label>
							<select class="form-control" name="server" id="login_server"<?php if (count($serverNames) === 1) echo ' disabled="disabled"' ?>>
								<?php foreach ($serverNames as $serverName): ?>
								<option value="<?php echo htmlspecialchars($serverName) ?>"><?php echo htmlspecialchars($serverName) ?></option>
								<?php endforeach ?>
							</select>
						</div>
						<?php endif ?>

						<?php if (Flux::config('UseLoginCaptcha')): ?>
						<div class="form-group">
							<?php if (Flux::config('EnableReCaptcha')): ?>
								<label for="register_security_code"><?php echo htmlspecialchars(Flux::message('AccountSecurityLabel')) ?></label>
								<div class="g-recaptcha" data-theme = "<?php echo $theme;?>" data-sitekey="<?php echo $recaptcha ?>"></div>
							<?php else: ?>
								<label for="register_security_code"><?php echo htmlspecialchars(Flux::message('AccountSecurityLabel')) ?></label>
								<div class="security-code">
									<img src="<?php echo $this->url('captcha') ?>" />
								</div>
								<input type="text" name="security_code" id="register_security_code" />
								<div style="font-size: smaller;" class="action">
									<strong><a href="javascript:refreshSecurityCode('.security-code img')"><?php echo htmlspecialchars(Flux::message('RefreshSecurityCode')) ?></a></strong>
								</div>
							<?php endif ?>
						</div>
						<?php endif ?>
						<button type="submit" class="btn btn-primary" role="button"><?php echo htmlspecialchars(Flux::message('LoginButton')) ?></button>
					</form>
				<?php endif ?>
			</div>
		</div>
	</div>
</div>


<?php if($VSC['slider_enable'] == true):?>
<div class="row pt-3">
	<div class="col">
		<div class="card">
			<div class="card-body p-0">
				<div id="carouselSidebarSlider" class="carousel slide carousel-fade" data-ride="carousel">
					<div class="carousel-inner">
						<?php for($i = 1; $i <= count($VSC['slider_data']); $i++):?>
						<div class="carousel-item<?php if($i == 1):?> active<?php endif ?>">
							<img src="<?php echo $this->themePath('img/sidebar_slider/'. $VSC['slider_data'][$i]['img']) ?>" class="d-block w-100" alt="...">
						</div>
						<?php endfor ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php endif ?>

<!--
	Play with this box if you want to!
<div class="row pt-3">
	<div class="col">
		<div class="card">
			<div class="card-body">
				<p class="card-text" id="sidebar-chat">
		<?php $rhairs = rand(1,6); $rhairc = rand(1,6); $hat = rand(21,120);
					$actstance = 4; // 0 = Stand
									// 1 = Fight
									// 2 = Sit
									// 3 = Pick up
									// 4 = Attack Stance
									// 5 = Attack Spell?
									// 6 = Take Damage
									// 7 = Take More Damage
									// 8 = Dead
 ?>
		<img src="<?php echo $VSC['chargen_url'] ?>generate/body=F-1-1/hair=<?php echo $rhairs ?>-<?php echo $rhairc ?>-0/hats=<?php echo $hat ?>-0-0/equip=0-0-0/option=0/actdir=0-<?php echo $actstance ?>-0">
				</p>
			</div>
		</div>
	</div>
</div>
 -->

<?php if($VSC['worldboss']):?>
<?php
	$worldbossvar = "\$WORLDBOSS";
	$sth = $server->connection->getStatement("SELECT `value` FROM {$server->charMapDatabase}.`mapreg` WHERE `varname` = '{$worldbossvar}' LIMIT 1");
	$sth->execute();
	$worldbosscount = $sth->fetch();
?>
<div class="row pt-3">
	<div class="col">
		<div class="card">
			<div class="card-header">World Boss</div>
			<div class="card-body">
				Required Kills: <?php echo ($VSC['worldboss_required_kills'] - $worldbosscount->value) ?>
			</div>
		</div>
	</div>
</div>
<?php endif ?>





<?php
// MVP Killed & Killers List Stuff
require_once 'Flux/TemporaryTable.php';
if($server->isRenewal) {
	$fromTables = array("{$server->charMapDatabase}.mob_db_re", "{$server->charMapDatabase}.mob_db2_re");
} else {
	$fromTables = array("{$server->charMapDatabase}.mob_db", "{$server->charMapDatabase}.mob_db2");
}
$tableName  = "{$server->charMapDatabase}.monsters";
$tempTable  = new Flux_TemporaryTable($server->connection, $tableName, $fromTables);

$sql = "SELECT `mvplog`.`monster_id`, {$tableName}.iName AS iName, count(*) AS count FROM {$server->logsDatabase}.`mvplog` ";
$sql.= "LEFT JOIN {$tableName} ON `id` = `mvplog`.`monster_id` ";
$sql.= "WHERE `mvplog`.`mvp_date` >= DATE(NOW() - INTERVAL 7 DAY) ";
$sql.= "GROUP BY `mvplog`.`monster_id` ORDER BY count DESC LIMIT 3";
$sth = $server->connection->getStatementForLogs($sql);
$sth->execute();
$killed = $sth->fetchAll();
?>



<div class="row pt-3">
	<div class="col">
		<div class="card">
			<div class="card-header">Most Recently Killed MvPs</div>
			<div class="card-body">
				<?php if($killed): ?>
					<ul class="killlist">
					<?php foreach($killed as $mvp):?>
					<li class="text-center killlist">
						<img class="killlistimg mx-auto d-block" src="<?php echo $VSC['chargen_url'].'monster/'. $mvp->monster_id ?>?nocache=<?php echo rand() ?>"><br />
						<?php echo $mvp->iName ?> (<?php echo $mvp->count ?>)
					</li>
					<?php endforeach ?>
					</ul>
				<?php else: ?>
					<em><small>No MVPs have been killed in the last 3 days</small></em>
				<?php endif ?>
			</div>
		</div>
	</div>
</div>

<?php if($VSC['facebook']['enable'] == true):?>
<div class="row pt-3">
	<div class="col">
		<div class="card">
			<div class="fb-page" data-href="https://www.facebook.com/<?php echo $VSC['facebook']['uri'] ?>/" data-tabs="<?php if($VSC['facebook']['display_timeline'] == true): ?>timeline<?php else:?>none<?php endif ?>" data-width="" data-height="322" data-small-header="false" data-adapt-container-width="true" data-hide-cover="true" data-show-facepile="false"><blockquote cite="https://www.facebook.com/<?php echo $VSC['facebook']['uri'] ?>/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/<?php echo $VSC['facebook']['uri'] ?>/">rAthena</a></blockquote></div>
		</div>
	</div>
</div>
<?php endif ?>




