<?php if (!defined('FLUX_ROOT')) exit; ?>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
	<div class="container">
		<a class="navbar-brand" href="//<?php echo Flux::config('ServerAddress').'/'.Flux::config('BaseURI'); ?>"><?php echo Flux::config('SiteTitle'); ?></a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarMainHeader" aria-controls="navbarMainHeader" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarMainHeader">
			<ul class="navbar-nav mr-auto">
				<?php $menuItems = $this->getMenuItems(); ?>
				<?php if (!empty($menuItems)): ?>
					<?php foreach ($menuItems as $menuCategory => $menus): ?>
						<?php if (!empty($menus)): ?>
							<li class="nav-item dropdown">
							<a href="#" class="nav-link dropdown-toggle" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo htmlspecialchars(Flux::message($menuCategory)) ?></a>
							<div class="dropdown-menu">
							<?php foreach ($menus as $menuItem):  ?>
								<a class="dropdown-item" href="<?php echo $menuItem['url'] ?>"><?php echo htmlspecialchars(Flux::message($menuItem['name'])) ?></a>
							<?php endforeach ?>
							</div>
							</li>
						<?php endif ?>
					<?php endforeach ?>
				<?php endif ?>
				<?php $adminMenuItems = $this->getAdminMenuItems(); ?>
				<?php if (!empty($adminMenuItems) && Flux::config('AdminMenuNewStyle')): ?>
							<li class="nav-item dropdown">
							<a href="#" class="nav-link dropdown-toggle" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Admin Menu</a>
							<div class="dropdown-menu">
							<?php foreach ($adminMenuItems as $menuItem): ?>
								<a class="dropdown-item" href="<?php echo $this->url($menuItem['module'], $menuItem['action']) ?>"><?php echo htmlspecialchars(Flux::message($menuItem['name'])) ?></a>
							<?php endforeach ?>
							</div>
							</li>
				<?php endif ?>
			</ul>
		</div><!--/.nav-collapse -->
	</div>
</nav>
