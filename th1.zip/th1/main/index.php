<?php
?>

<div class="row row-cols-1 row-cols-md-<?php echo $VSC['news_items_per_row'] ?> pb-4">

	<?php if($newstype == '1'):?>
		<?php if($news): ?>
			<?php foreach($news as $nrow):?>
				<?php
				// These News Images are stored in /themes/<theme_name>/img/news/
				// In the if-statement, use the name of your News item to dsiplay $newsimage in the feed.
				if($nrow->title == "The League Of Levelers"){$newsimage = "league";}
				elseif($nrow->title == "Halloween Has Landed"){$newsimage = "halloween";}
				else{$newsimage = "generic";}
				?>
				<div class="col mb-4">
					<div class="card h-100">
						<div class="card-header"><strong><?php echo $nrow->title ?></strong></div>
						<img src="<?php echo $this->themePath('img/news/'.$newsimage.'.jpg') ?>" class="card-img-top" alt="<?php echo $nrow->title ?>">
						<div class="card-body"><p><?php echo substr($nrow->body,0,180) ?>...</p></div>
						<div class="card-footer text-muted">
							<span class="newsDate"><small>by <?php echo $nrow->author ?> on <?php echo date(Flux::config('DateFormat'),strtotime($nrow->created))?></small></span>
							<?php if($nrow->created != $nrow->modified && Flux::config('CMSDisplayModifiedBy')):?>
								<small><?php echo htmlspecialchars(Flux::message('CMSModifiedLabel')) ?> : <?php echo date(Flux::config('DateFormat'),strtotime($nrow->modified))?></small>
							<?php endif; ?>
							<?php if($nrow->link): ?>
							<a class="news_link" href="<?php echo $nrow->link ?>"><small><?php echo htmlspecialchars(Flux::message('CMSNewsLink')) ?></small></a>
							<div class="clear"></div>
							<?php endif; ?>
						</div>
					</div>
				</div>
			<?php endforeach; ?>
		<?php else: ?>
			<p><?php echo htmlspecialchars(Flux::message('CMSNewsEmpty')) ?></p>
		<?php endif ?>

	<?php elseif($newstype == '2'):?>
		<?php if(isset($xml) && isset($xml->channel)): ?>
			<?php foreach($xml->channel->item as $rssItem): ?>
				<?php $i++; if($i <= $newslimit): ?>
					<?php
					// These News Images are stored in /themes/<theme_name>/img/news/
					// In the if-statement, use the name of your News item to dsiplay $newsimage in the feed.
					if($rssItem->title == "The League Of Levelers"){$newsimage = "league";}
					elseif($rssItem->title == "Halloween Has Landed"){$newsimage = "halloween";}
					else{$newsimage = "generic";}
					?>
					<div class="col mb-4">
						<div class="card h-100">
							<div class="card-header"><strong><?php echo $rssItem->title ?></strong></div>
							<img src="<?php echo $this->themePath('img/news/'.$newsimage.'.jpg') ?>" class="card-img-top" alt="<?php echo $rssItem->title ?>">
							<div class="card-body"><p><?php echo substr($rssItem->description,0,180) ?>...</p></div>
							<div class="card-footer text-muted">
								<span class="newsDate">Posted <?php echo date(Flux::config('DateFormat'),strtotime($rssItem->pubDate))?></small></span>
								<?php if($rssItem->link): ?>
								<a class="news_link" href="<?php echo $rssItem->link ?>"><small><?php echo htmlspecialchars(Flux::message('CMSNewsLink')) ?></small></a>
								<div class="clear"></div>
								<?php endif; ?>
							</div>
						</div>
					</div>
				<?php endif ?>
			<?php endforeach; ?>
		<?php else: ?>
			<p>
				<?php echo htmlspecialchars(Flux::message('CMSNewsRSSNotFound')) ?><br/><br/>
			</p>
		<?php endif ?>
	<?php endif ?>
</div>


<div class="row pb-4">
	<div class="col mb-4">
		<div class="card">
			<div class="card-body">
				<h3>Welcome to <?php echo Flux::config('SiteTitle') ?>!</h3>
				<p>
					Greetings, Adventurer!<br /><br />
					The server owner can edit this text in <?php echo $this->themePath('main/index.php') ?> <br /><br />
					Head on over to the <a href="<?php echo $this->url('account', 'create') ?>">registration page</a> and give us a go!<br />
					Hope you see you in-game,<br />
					<em>Server Owner</em>
				</p>
			</div>
		</div>
	</div>
</div>

<div class="row pb-4">
	<div class="col">
		<div class="card">
			<div class="card-header">Something to Watch!</div>
			<div class="card-body p-0">
				<iframe width="395" height="296" src="https://www.youtube.com/embed/<?php echo $VSC['youtube_video']?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
			</div>
		</div>
	</div>

	<div class="col">
		<div class="card">
			<div class="card-header">Screenshots of our Community</div>
			<div class="card-body p-0" style="min-height: 296px;">
				<div id="carouselScreenshotSlider" class="carousel slide" data-ride="carousel">
					<div class="carousel-inner">
						<?php for($i = 0; $i < count($VSC['screenshots']); $i++):?>
						<div class="carousel-item<?php if($i == 0):?> active<?php endif ?>">
							<a data-toggle="modal" data-target="#ss<?php echo $i ?>"><img src="<?php echo $this->themePath('img/screenshots/'. $VSC['screenshots'][$i]) ?>" class="d-block w-100" alt="..."></a>
						</div>
						<div class="modal fade" id="ss<?php echo $i ?>" tabindex="-1" role="dialog" aria-hidden="true">
							<div class="modal-dialog modal-xl" role="document">
								<div class="modal-content">
									<div class="modal-body"><img src="<?php echo $this->themePath('img/screenshots/'. $VSC['screenshots'][$i]) ?>" class="d-block w-100" alt="..."></div>
								</div>
							</div>
						</div>
						<?php endfor ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>





