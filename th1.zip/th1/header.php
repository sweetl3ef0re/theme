<?php if (!defined('FLUX_ROOT')) exit; ?>
<?php $VSC = include 'theme_config.php' ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="description" content="<?php echo $VSC['meta_description'] ?>">
		<meta name="author" content="<?php echo $VSC['meta_author'] ?>">

		<?php if (isset($metaRefresh)): ?>
		<meta http-equiv="refresh" content="<?php echo $metaRefresh['seconds'] ?>; URL=<?php echo $metaRefresh['location'] ?>" />
		<?php endif ?>
		<title><?php echo Flux::config('SiteTitle'); if (isset($title)) echo ": $title" ?></title>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
		<link href="<?php echo $this->themePath('css/flux/unitip.css') ?>" rel="stylesheet" type="text/css" media="screen" title="" charset="utf-8" />
		<link rel="stylesheet" href="<?php echo $this->themePath('css/flux.css') ?>" type="text/css" media="screen" title="" charset="utf-8" />
		<link rel="stylesheet" href="<?php echo $this->themePath('css/theme.css') ?>" type="text/css" media="screen" title="" charset="utf-8" />
		<link rel="icon" type="image/x-icon" href="./favicon.ico" />
		<script src="https://kit.fontawesome.com/d3c6f04b16.js" crossorigin="anonymous"></script>
		<?php if (Flux::config('EnableReCaptcha')): ?>
		<script src='https://www.google.com/recaptcha/api.js'></script>
		<?php endif ?>
		<!--[if IE]>
		<link rel="stylesheet" href="<?php echo $this->themePath('css/flux/ie.css') ?>" type="text/css" media="screen" title="" charset="utf-8" />
		<![endif]-->

		<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
			<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
	</head>
	<body>
		<?php if($VSC['facebook']['enable'] == true):?>
		<div id="fb-root"></div>
		<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v6.0&appId=<?php echo $VSC['facebook']['app_id']?>&autoLogAppEvents=1"></script>
		<?php endif ?>
    <!-- Include Navbar -->
	<?php include $this->themePath('main/navbar.php', true) ?>
	<!-- End Navbar -->


    <div class="container pagecontainer">
		<?php //include 'main/sidebar.php' ?>
		<?php //include 'main/loginbox.php' ?>
			<?php if (Flux::config('DebugMode') && @gethostbyname(Flux::config('ServerAddress')) == '127.0.0.1'): ?>
				<p class="notice">Please change your <strong>ServerAddress</strong> directive in your application config to your server's real address (e.g., myserver.com).</p>
			<?php endif ?>
		<!-- Messages -->
		<?php if ($message=$session->getMessage()): ?>
		<p class="message"><?php echo htmlspecialchars($message) ?></p>
		<?php endif ?>
		<!-- Sub menu -->
		<?php include $this->themePath('main/submenu.php', true) ?>
		<!-- Page menu -->
		<?php include $this->themePath('main/pagemenu.php', true) ?>
		<!-- Credit balance -->
		<?php //if (in_array($params->get('module'), array('donate', 'purchase'))) include 'main/balance.php' ?>

		<?php if($VSC['announcement']['enable'] == true):?>
			<div class="alert alert-<?php echo $VSC['announcement']['colour'] ?>">
				<?php if($VSC['announcement']['icon'] != '#'):?><i class="fa <?php echo $VSC['announcement']['icon'] ?>"></i>&nbsp;<?php endif ?>
				<?php echo $VSC['announcement']['text'] ?>
			</div>
		<?php endif ?>

		<div class="row">
			<div class="col">
