<?php if (!defined('FLUX_ROOT')) exit; ?>
<h2><?php echo htmlspecialchars(Flux::message('ServerInfoHeading')) ?></h2>
<p><?php echo htmlspecialchars(Flux::message('ServerInfoText')) ?></p>

<h3><?php echo htmlspecialchars(sprintf(Flux::message('ServerInfoSubHeading'), $server->serverName)) ?></h3>
<div class="generic-form-div p-0">
	<table class="table">
		<tr>
			<th><label><?php echo htmlspecialchars(Flux::message('ServerInfoAccountLabel')) ?></label></th>
			<th><label><?php echo htmlspecialchars(Flux::message('ServerInfoCharLabel')) ?></label></th>
			<th><label><?php echo htmlspecialchars(Flux::message('ServerInfoGuildLabel')) ?></label></th>
			<th><label><?php echo htmlspecialchars(Flux::message('ServerInfoZenyLabel')) ?></label></th>
		</tr>
		<tr>
			<td><p><?php echo number_format($info['accounts']) ?></p></td>
			<td><p><?php echo number_format($info['characters']) ?></p></td>
			<td><p><?php echo number_format($info['guilds']) ?></p></td>
			<td><p><?php echo number_format($info['zeny']) ?></p></td>
		</tr>
	</table>
</div>

<h3><?php echo htmlspecialchars(sprintf(Flux::message('ServerInfoSubHeading2'), $server->serverName)) ?> <small>Keep refreshing to change the sprites</small></h3>
<div class="p-0">
	<div class="row row-cols-4">
		<?php $i = 0; $x = 5 ?>
		<?php foreach ($info['classes'] as $class => $total): ?>
			<?php $class_array = include(FLUX_CONFIG_DIR .'/jobs.php'); ?>
			<?php $class_id = array_search($class, $class_array); ?>
			<div class="col-3">
				<div class="row">
					<div class="col">
						<?php $rhairs = rand(1,6); $rhairc = rand(1,6); $gender = rand(1,2); $hat = rand(21,120);  $i++;?>
						<img src="<?php echo $VSC['chargen_url'] ?>generate/body=<?php if($gender == 1):?>M<?php else: ?>F<?php endif ?>-<?php echo $class_id ?>-0/hair=<?php echo $rhairs ?>-<?php echo $rhairc ?>-0/hats=<?php echo $hat ?>-0-0/equip=0-0-0/option=0/actdir=0-0-0">
					</div>
					<div class="col text-center">
						<label><?php echo $class ?></label> <p class="important"><?php echo number_format($total) ?></p>
					</div>
				</div>
			</div>
		<?php endforeach ?>
	</div>
</div>
