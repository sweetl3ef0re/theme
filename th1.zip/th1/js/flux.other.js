function updatePreferredServer(sel){
	var preferred = sel.options[sel.selectedIndex].value;
	document.preferred_server_form.preferred_server.value = preferred;
	document.preferred_server_form.submit();
}

function updatePreferredTheme(sel){
	var preferred = sel.options[sel.selectedIndex].value;
	document.preferred_theme_form.preferred_theme.value = preferred;
	document.preferred_theme_form.submit();
}

function updatePreferredLanguage(sel){
	var preferred = sel.options[sel.selectedIndex].value;
	setCookie('language', preferred);
	reload();
}

function toggleSearchForm() {
	//$('.search-form').toggle();
	$('.search-form').slideToggle('fast');
}

function setCookie(key, value) {
	var expires = new Date();
	expires.setTime(expires.getTime() + expires.getTime()); // never expires
	document.cookie = key + '=' + value + ';expires=' + expires.toUTCString();
}
